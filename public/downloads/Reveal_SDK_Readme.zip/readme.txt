--------------------------------------------------------------------------------
                            REVEAL SDK README
--------------------------------------------------------------------------------

Thank you for downloading the Reveal SDK!

Reveal is a business intelligence solution that is purpose-built for embedded 
analytics. Deliver full-featured self-service dashboards and modern reporting 
with a beautiful, branded experience in any JavaScript framework, Windows Forms 
or WPF application. Deploy to any cloud – public or private – or your own 
on-prem servers. This guide will walk you through installing the SDK and adding 
a license key to begin harnessing these capabilities in your applications.

--------------------------------------------------------------------------------
TABLE OF CONTENTS
--------------------------------------------------------------------------------

1. WPF Installation
2. Web Installation
   a. Server Installation
   b. Client Installation
3. Adding a License Key
4. Samples
5. Trial License Key Information
6. Support & Community

--------------------------------------------------------------------------------
1. WPF INSTALLATION
--------------------------------------------------------------------------------

To integrate Reveal into your WPF application, follow the guide:
- WPF Installation: https://help.revealbi.io/wpf/installation

ADDING WPF LICENSE KEY:
- Add WPF License Key: https://help.revealbi.io/wpf/adding-license-key

--------------------------------------------------------------------------------
2. WEB INSTALLATION
--------------------------------------------------------------------------------

SERVER INSTALLATION:
- Web Server SDK: https://help.revealbi.io/web/install-server-sdk

CLIENT INSTALLATION:
- Web Client SDK: https://help.revealbi.io/web/install-client-sdk

ADDING WEB LICENSE KEY:
- Add Web License Key: https://help.revealbi.io/web/adding-license-key

--------------------------------------------------------------------------------
3. SAMPLES
--------------------------------------------------------------------------------

WPF Samples:
- GitHub: https://github.com/RevealBi/sdk-samples-wpf

Web Samples:
- GitHub: https://github.com/RevealBi/sdk-samples-javascript

--------------------------------------------------------------------------------
4. TRIAL LICENSE KEY INFORMATION
--------------------------------------------------------------------------------

A trial license key will be sent to your email within 5-10 minutes. If not 
received, please contact: sales@revealbi.io

--------------------------------------------------------------------------------
5. SUPPORT & COMMUNITY
--------------------------------------------------------------------------------

DOCUMENTATION:
- Official Documentation: https://help.revealbi.io/

FEATURE REQUESTS & ISSUES:
- GitHub: https://github.com/RevealBi/Reveal.Sdk/issues

JOIN OUR DISCORD CHANNEL:
- Discord Invite: https://discord.gg/Ped3sSK5Xw

--------------------------------------------------------------------------------
Thank you for choosing the Reveal SDK. For questions, refer to our documentation,
reach out to our support, or join our community. Happy coding!
--------------------------------------------------------------------------------
